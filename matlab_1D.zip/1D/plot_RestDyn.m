function plot_RestDyn(BCL0,control,Fsize)

% File .mat with restitution data order as follow:
%
% File .mat with restitution data order as follow:
%
% Col  1: BCL
% Col  2: APD90 n-1
% Col  3: APD90 n
% Col  4: APD20 n
% Col  5: APD50 n
% Col  6: APD80 n
% Col  7: RMP n
% Col  8: APA n
% Col  9: dVdtmax n
% Col 10: DI
% Col 11: CaT20 n
% Col 12: CaT50 n
% Col 13: CaT80 n
%
% control: 0 does not plot control curve
%          1 plot control curve

fname = sprintf('Dynrest_%d.mat',BCL0);
load(fname,'Dyn');
DImod = Dyn(:,10);

fp3 = figure(3);
sgtitle('Dynamic Restitution Curve','FontSize',20)
fp3sp1 = subplot(2,3,1); hold
fp3sp2 = subplot(2,3,2); hold
fp3sp3 = subplot(2,3,3); hold
fp3sp4 = subplot(2,3,4); hold
fp3sp5 = subplot(2,3,5); hold
fp3sp6 = subplot(2,3,6); hold

% APD90
plot(fp3sp1,DImod,Dyn(:,3),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp1,'DI (ms)');
ylabel(fp3sp1,'APD_{90} (ms)');
xlim(fp3sp1,[50 700]);
ylim(fp3sp1,[100 220]);
grid(fp3sp1,'on');

% APD80
plot(fp3sp2,DImod,Dyn(:,6),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp2,'DI (ms)');
ylabel(fp3sp2,'APD_{80} (ms)');
xlim(fp3sp2,[50 700]);
ylim(fp3sp2,[100 200]);
grid(fp3sp2,'on');

% APD50
plot(fp3sp3,DImod,Dyn(:,5),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp3,'DI (ms)');
ylabel(fp3sp3,'APD_{50} (ms)');
xlim(fp3sp3,[50 700]);
ylim(fp3sp3,[80 180]);
grid(fp3sp3,'on');

% RMP
plot(fp3sp4,DImod,Dyn(:,7),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp4,'DI (ms)');
ylabel(fp3sp4,'RMP (mV)');
xlim(fp3sp4,[50 700]);
ylim(fp3sp4,[-85 -70]);
grid(fp3sp4,'on');

% APA
plot(fp3sp5,DImod,Dyn(:,8),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp5,'DI (ms)');
ylabel(fp3sp5,'APA (mV)');
xlim(fp3sp5,[50 700]);
ylim(fp3sp5,[80 120]);
grid(fp3sp5,'on');

% dVdtmax
plot(fp3sp6,DImod,Dyn(:,9),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp3sp6,'DI (ms)');
ylabel(fp3sp6,'upstrooke (V/s)');
xlim(fp3sp6,[50 700]);
ylim(fp3sp6,[0 50]);
grid(fp3sp6,'on');

% Calcium
fp5 = figure(5);
sgtitle('Calcium Dynamic Restitution Curve','FontSize',20)
fp5sp1 = subplot(2,3,1); hold; grid on;
fp5sp2 = subplot(2,3,2); hold; grid on;
fp5sp3 = subplot(2,3,3); hold; grid on;

% CaTD80
plot(fp5sp1,Dyn(1:end-2,1),Dyn(1:end-2,13),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp5sp1,'BCL (ms)');
ylabel(fp5sp1,'CaTD_{80} (ms)');
xlim(fp5sp1,[200 900]);
ylim(fp5sp1,[100 400]);
grid(fp5sp1,'on');

% CaTD50
plot(fp5sp2,Dyn(1:end-2,1),Dyn(1:end-2,12),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp5sp2,'BCL (ms)');
ylabel(fp5sp2,'CaTD_{50} (ms)');
xlim(fp5sp2,[200 900]);
ylim(fp5sp2,[50 300]);
grid(fp5sp2,'on');

% CaTD20
plot(fp5sp3,Dyn(1:end-2,1),Dyn(1:end-2,11),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp5sp3,'BCL (ms)');
ylabel(fp5sp3,'CaTD_{20} (ms)');
xlim(fp5sp3,[200 900]);
ylim(fp5sp3,[50 250]);
grid(fp5sp3,'on');

legend(fp3sp1,'location','best');
legend(fp5sp1,'location','best');

end