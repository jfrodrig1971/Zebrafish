function flag_exit = fd1D_ZFvec(BCL,nrepeat,protocol,BCLseq,ICfile,chkpointFile)

% 1D Finite difference program for the monodomain
% equation. It uses Operator Splitting with Implicit
% Euler for the diffusion equation and Explicit Euler
% for the Ionic Currents
%
% Input parameters:
% BCL          : Basic cycle length
% nrepeat      : Number of repetitions to stimulate at the given BCL
% protocol     : Stimulation protocol
%                0 Steady state
%                1 S1S2 restitution (BCL_seq must be specified)
%                2 Dynamic restitution (BCL_seq must be specified)
% BCLseq       : Only for protocol=1, array of S2 stimuli (BCLs)
% ICfile       : File with initial condition to be assigned to all cells
% chkpointFile : Check point file from a 1D simulation

% ----------------------------------------------
%   MODIFIABLE PARAMETERS
% ----------------------------------------------

% General Data
outfreq = 10;

% Geometry and spatial discretization
L = 0.99;           % Total length [mm]
dx = 0.03;          % [mm]

% Conductance
Dcoef = 1.76e-02;   % [mm^2/ms] Cable conductivity (dffusion coefficient)
Cm = 1.0;           % [microF/cm^2] Cell membrane capacitance

% Time integration
dt = 0.02;          % [ms]

num_method = 0;     % num_method: 0 (Explicit Euler)
                    % 1 (Implicit Euler)
                    % 0.5 (Crank-Nicolson)

% Stimulation time
dtstim = 1.0;       % Stimulation duration
Stim_curr = -500.0; % Stimulation current (2*threshold)
tbegin = 0.0;       % Begining of stimulus
node_st = 1;        % Node for stimulation

% ----------------------------------------------
%   END OF MODIFIABLE PARAMETERS
% ----------------------------------------------

% Generating Mesh
nel = fix(L/dx);
nnd = nel + 1;
x = [0.0:dx:L]';   % Nodal coordinates

% Initializing cell structure and initial verification
if(isempty(ICfile)&&isempty(chkpointFile))
  fprintf('Using default Initial Conditions\n');
  V = initial_cond(nnd,0,[]);
elseif(~isempty(chkpointFile))
  fprintf('Using Initial Conditions from Check point file: %s\n',chkpointFile);
  V = initial_cond(nnd,2,chkpointFile);
else
  fprintf('Using Initial Conditions from IC file: %s\n',ICfile);  
  V = initial_cond(nnd,1,ICfile);
end

% Assembling A matrix
fprintf('Assembling finite difference matrices ...\n');
[B1,B2] = assembling(num_method,Dcoef,Cm,nnd,dx,dt);

% Loading parameters
p = mod_param();    % Loading model parameters
tstart = tic;
switch protocol
  case 0
    fprintf('Running SS protocol\n');
    fprintf('Initiating preconditioning with %d beats at BCL %.1f ms\n',nrepeat,BCL);
    for j = 1:nrepeat
       tspan = [0 BCL];
       saveflag = 0;
       fprintf('Beat %d/%d\n',j,nrepeat);
       Vnew = solver(tspan,Cm,V,p,x,dt,BCL,dtstim,Stim_curr,1,outfreq,...
                   saveflag,[],num_method,B1,B2);
       V = Vnew;
    end
    fprintf('Finished preconditioning. Initiating last two beats\n'); 
    tspan = [0 2*BCL];
    saveflag=1;
    fname = sprintf('SS_%d.mat',BCL);
    Vnew = solver(tspan,Cm,V,p,x,dt,BCL,dtstim,Stim_curr,1,outfreq,...
                saveflag,fname,num_method,B1,B2);
    V = Vnew;
    sname = sprintf('chkpointSS%d.mat',BCL);
    save(sname,'V');
	
  case 1
    fprintf('Running S1S2 protocol\n');
    if(isempty(BCLseq))
      fprintf('BCL sequence do not specified ... Exiting\n');
      return;
    else
      fprintf('%d S2 stimulus considered with %d S1 stimulus at BCL %.1f\n',length(BCLseq),nrepeat,BCL);  
    end
    for k=1:length(BCLseq)
      fprintf('S2: %.1f\n',BCLseq(k));
      for j=1:nrepeat
        tspan = [0 BCL];
        saveflag = 0;
        Vnew=solver(tspan,Cm,V,p,x,dt,BCL,dtstim,Stim_curr,1,outfreq,...
                    saveflag,[],num_method,B1,B2);
        V = Vnew;
      end
      tspan = [0 BCLseq(k)+BCL];
      saveflag = 1;
      fname = sprintf('S1S2_%d_%d.mat',BCL,BCLseq(k));
      Vnew=solver(tspan,Cm,V,p,x,dt,BCLseq(k),dtstim,Stim_curr,0,outfreq,...
                  saveflag,fname,num_method,B1,B2);
      V = Vnew;            
    end
	
  case 2
    fprintf('Running Dyn protocol\n');
    if(isempty(BCLseq))
      fprintf('BCL sequence do not specified ... Exiting\n');
      return;
    else
      fprintf('%d BCLs considered with %d stimulations\n',length(BCLseq),nrepeat);  
    end
    for k=1:length(BCLseq)
      fprintf('BCL: %.1f\n',BCLseq(k));
      for j=1:(nrepeat-3)
        tspan = [0 BCLseq(k)];
        saveflag=0;
        Vnew=solver(tspan,Cm,V,p,x,dt,BCL,dtstim,Stim_curr,1,outfreq,...
                    saveflag,[],num_method,B1,B2);
        V = Vnew;
      end
      tspan = [0 3*BCLseq(k)];
      saveflag=1;
      fname = sprintf('Dyn_%d.mat',BCLseq(k));
      Vnew=solver(tspan,Cm,V,p,x,dt,BCLseq(k),dtstim,Stim_curr,1,outfreq,...
                  saveflag,fname,num_method,B1,B2);
      V = Vnew;            
    end
end
telapsed = toc(tstart);
fprintf('Simulation time: %.2f s\n',telapsed);
flag_exit=1;
return

function Vnew = solver(tspan,Cm,V,p,x,dt,BCL,dtstim,Stim_curr,stimflag,outfreq,...
                     saveflag,fname,num_method,B1,B2)

% This function executes the 1D integration
%
% stimflag: 1 executes stimulations at BCL
%           0 executes stimultion at t=0 and t=BCL only (use for S1S2
%             protocol

nnd = length(V.V);
simtime = tspan(end)-tspan(1);
ntmp = ceil(simtime/dt);

if(saveflag==1)
  ntmpsave = 1;
  contout = 1;
  buffsize = length(1:outfreq:(ntmp-ntmpsave+1));   % size of output vectors
  out=dimbuffer(buffsize,nnd+1);
  [V,cur] = currents(nnd,V,p,0,dt,0.0);
  out = storebuffer(contout,0.0,V,cur,out);
  contout = contout + 1;   
end

%fprintf('Initiating temporal integration\n');
t = 0.0;
tbegin = 0.0;
tend = tbegin + dtstim;
invCm = 1.0/Cm;

%tic
xsol = zeros(nnd,1);
Istim = zeros(nnd,1);
flag_stm = 1.0;
contstm = 1;

%tic
for i = 1:ntmp
% Integrating cellular model in the nodes
    if (t >= tbegin && t <= tend)
        Istim(1) = Stim_curr;
        flag_stm = 0.0;
    else
        Istim(1) = 0.0;
        if(flag_stm < 1.0)
           tbegin = tbegin + BCL;
           tend = tbegin + dtstim;
           flag_stm = 1.0;
           contstm = contstm + 1;
           if((stimflag<1)&&(contstm>2))
              tbegin = tspan(end);
              tend = tspan(end)+dtstim;     
           end
        end
    end

    [V,cur] = currents(nnd,V,p,t,dt,Istim);
    xsol = V.V - invCm*V.Itot*dt;     % xsol continains the value of V* 

% Solving for the propagation of electric signal (Step 2)

    switch(num_method)
        case 0 % Explicit Finite differences
            V.V = xsol + B2*V.V;
        case 1 % Implicit Finite differences
            [V.V,flag] = pcg(B1,xsol,1.0e-8,100,[],[],xsol);
        case 2
            [V.V,flag] = pcg(B1,xsol+B2*V.V,1.0e-8,100,[],[],xsol);
     end

    xsol = V.V;
    V.V = xsol;

    t = t + dt;
%      if (mod(i,500) == 0)
%          fprintf('Step: %d Time: %15.4f Vmax: %15.4f Vmid: %15.4f\n',i,t,max(xsol),xsol(ceil(nnd/2)));  
%      end
    % Writing to Output file
    if ((mod(i,outfreq) == 0) && (saveflag>0))
       out=storebuffer(contout,t,V,cur,out);
       contout = contout + 1;
    end
end
%toc
if(saveflag > 0)
  save(fname,'x','out');
end
Vnew = V;
% if(chkpointSave)
%     save('chkpoint.mat','V');
% end
return

%-------------------------------------------

function V = initial_cond(nnd,flag,fname)

% This function sets the initial conditions
% for the Ten Tusscher Model
%
% V is the main structure which contains the
% membrane potential, ioninc concentrations, and
% gate variables

switch flag
    case 0
        V.V = -80.5174*ones(nnd,1);                     % [mV]
        V.Cai = 0.0002*ones(nnd,1);                     % [mM]
        V.CaSR = 0.2*ones(nnd,1);                       % [mM]
        V.Nai = 11.6*ones(nnd,1);                       % [mM]
        V.Ki = 109*ones(nnd,1);                         % [mM]
        V.m = 0.0*ones(nnd,1);      
        V.h = 0.75*ones(nnd,1);      
        V.j = 0.75*ones(nnd,1);      
        V.xr1 = 0.0*ones(nnd,1); 
        V.xr2 = 0.1*ones(nnd,1);    
        V.xs = 0.0*ones(nnd,1);     
        V.dL = 0.0*ones(nnd,1);   
        V.fL = 1.0*ones(nnd,1);      
        V.fca = 1.0*ones(nnd,1);
        V.dT = 0.0026*ones(nnd,1); 
        V.fT = 0.742*ones(nnd,1);    
        V.g = 1.0*ones(nnd,1);       
        V.Itot = 9.5371e-5*ones(nnd,1);                 % [mA]
		
    case 1
        load(fname,'STATES0');
        V.V = STATES0(1)*ones(nnd,1);                   % [mV]
        V.Cai = STATES0(2)*ones(nnd,1);                 % [mM]
        V.CaSR = STATES0(3)*ones(nnd,1);                % [mM]
        V.Nai = STATES0(5)*ones(nnd,1);                 % [mM]
        V.Ki = STATES0(6)*ones(nnd,1);                  % [mM]
        V.m = STATES0(7)*ones(nnd,1); 
        V.h = STATES0(8)*ones(nnd,1);     
        V.j = STATES0(9)*ones(nnd,1);      
        V.xr1 = STATES0(10)*ones(nnd,1); 
        V.xr2 = STATES0(11)*ones(nnd,1);
        V.xs = STATES0(12)*ones(nnd,1);
        V.dL = STATES0(13)*ones(nnd,1);                
        V.fL = STATES0(14)*ones(nnd,1);                              
        V.fca = STATES0(15)*ones(nnd,1);                        
        V.dT = STATES0(16)*ones(nnd,1);          
        V.fT = STATES0(17)*ones(nnd,1);
        V.g = STATES0(4)*ones(nnd,1);
        V.Itot = zeros(nnd,1);                           % [pA/pF]      
  case 2
    load(fname,'V');
end
return

%-------------------------------------------

function p = mod_param()

% This function returns the model parameters
% for the Ten Tusscher Model
%
% KHWJ ten Tusscher, D Noble, PJ Noble, AV Panfilov. 
%  Am J Phys 286:H1573-H1589, 2004.
% KHWJ ten Tusscher and AV Panfilov. 
%  Am J Phys 291:H1088-H1100, 2006

% Constants
p.R = 8314.472;              % J/(kmol*K)
p.T = 301.0;                 % K
p.F = 96485.3415;            % C/mol
p.RTF = p.R*p.T/p.F;         % kJ/C

% Capacitance
p.Cap = 1.0;                 % microF/cm^2

% Intracellular Volume and Capacitive Area
p.Vc = 390.0e-9;             % micro_L
p.Ac = 3000.0e-8;            % cm^2
p.Vsr = 0.05*p.Vc;           % micro_L

% External concentrations
p.Ko = 4.85;                 % mM
p.Nao = 142.0;               % mM
p.Cao = 1.8;                 % mM

% Parameters for IKr
p.GKr = 0.7776;              % mS/microF

% Parameters for IKs
p.pKNa = 0.03;  
p.GKs = 0.0648;              % mS/microF

% Parameters for IK
p.GK1 = 0.3490;              % mS/microF

% Parameters for INa
p.GNa = 1.0;                 % mS/microF

% Parameter for IbNa
p.GbNa = 3.8137e-4;          % mS/microF

% Parameters for INaK
p.KmK = 1.0;                 % mM
p.KmNa = 40.0;               % mM
p.PNaK = 4.0860;             % microA/microF

% Parameters for ICaL
p.GCaL = 2.3843e-04;         % cm^3/(s*microF)

% Parameters for ICaT
p.GCaT = 0.0660;

% Parameter for IbCa
p.GbCa = 6.6387e-4;         % mS/microF

% Parameter for INaCa
p.kNaCa = 1000.0;           % microA/microF
p.KmNai = 87.5;             % mM
p.KmCa = 1.38;              % mM
p.ksat = 0.1;       
p.gam = 0.35;       
p.alf = 2.5;         

% Parameter for IpCa
p.GpCa = 0.0456;            % mS/microF
p.KpCa = 5.0e-4;            % mM

% Intracellular calcium flux dynamics
p.Vmxu = 0.000425;          % mM/ms
p.arel = 0.0132;            % mM/ms
p.brel = 0.25;              % 1/(mM^2*ms)
p.crel = 0.0066;            % mM/ms
p.Kup = 0.00025;            % mM
p.taug = 3.0;               % ms
p.Vleak = 8.0e-5;           % mM/ms
p.gIrel = 1.0;              % Irel scaling factor

% Calcium buffering dynamics
p.Bufc = 0.19;              % mM
p.Kbufc = 0.001;            % mM
p.Bufsr = 10.0;             % mM
p.Kbufsr = 0.3;             % mM

return

%-------------------------------------------

function [B1,B2] = assembling(num_meth,Dcoef,Cm,nnd,dx,dt)

% Function for assembling the A matrix for the FD scheme
%
%  (flag*A+I)V^(k+1) = V^* + (1+flag)*A*V^k
%
%   flag: 0 (Explicit Euler)
%         1 (Implicit Euler)
%        0.5(Crank-Nicolson)
%
% num_meth: Numerical scheme
% Dcoef   : Conductivity
% Cm      : Capacitance
% nnd     : Number of nodes
% dx      : element size
% dt      : time step

A = sparse(zeros(nnd));
scale = Dcoef*dt/(Cm*dx^2);
fprintf('Assembling matrix A\n');
for ii = 1:nnd
    switch ii
        case 1
            A(ii,ii) = -2*scale;
            A(ii,ii+1) = 2*scale;
        case nnd
            A(ii,ii) = -2*scale;
            A(ii,ii-1) = 2*scale;
        otherwise
            A(ii,ii) = -2*scale;
            A(ii,ii+1) = scale;
            A(ii,ii-1) = scale;
    end
end
switch num_meth
    case 0
        B1 = [];
        B2 = A;
    case 1
        B1 = sparse(eye(nnd))-A;
        B2 = [];
    case 2
        B1 = sparse(eye(nnd))-0.5*A;
        B2 = 0.5*A;
    otherwise
        B1 = [];
        B2 = [];
end
fprintf('Assembling finished\n');
return

function out = storebuffer(contout,t,V,cur,out)

  out.V(contout,:) = [t V.V'];
  out.Cai(contout,:) = [t V.Cai'];
  out.CaSR(contout,:) = [t V.CaSR'];
  out.Nai(contout,:) = [t V.Nai'];
  out.Ki(contout,:) = [t V.Ki'];
  out.m(contout,:) = [t V.m'];
  out.h(contout,:) = [t V.h'];
  out.j(contout,:) = [t V.j'];
  out.xr1(contout,:) = [t V.xr1'];
  out.xr2(contout,:) = [t V.xr2'];
  out.xs(contout,:) = [t V.xs'];
  out.dL(contout,:) = [t V.dL'];
  out.fL(contout,:) = [t V.fL'];
  out.fca(contout,:) = [t V.fca'];
  out.dT(contout,:) = [t V.dT'];
  out.fT(contout,:) = [t V.fT'];
  out.g(contout,:) = [t V.g'];
  out.IKr(contout,:) = [t cur.IKr'];
  out.IK1(contout,:) = [t cur.IK1'];
  out.INa(contout,:) = [t cur.INa'];
  out.IbNa(contout,:) = [t cur.IbNa'];
  out.ICaL(contout,:) = [t cur.ICaL'];
  out.ICaT(contout,:) = [t cur.ICaT'];
  out.IKs(contout,:) = [t cur.IKs'];
  out.INaCa(contout,:) = [t cur.INaCa'];
  out.INaK(contout,:) = [t cur.INaK'];
  out.IpCa(contout,:) = [t cur.IpCa'];
  out.IbCa(contout,:) = [t cur.IbCa'];
  out.Irel(contout,:) = [t cur.Irel'];
  out.Iup(contout,:) = [t cur.Iup'];
  out.Ileak(contout,:) = [t cur.Ileak'];
return
   
function out = dimbuffer(nrow,ncol)
      
  out.V = zeros(nrow,ncol);
  out.Cai = zeros(nrow,ncol);
  out.CaSR = zeros(nrow,ncol);
  out.Nai = zeros(nrow,ncol);
  out.Ki = zeros(nrow,ncol);
  out.m = zeros(nrow,ncol);
  out.h = zeros(nrow,ncol);
  out.j = zeros(nrow,ncol);
  out.xr1 = zeros(nrow,ncol);
  out.xr2 = zeros(nrow,ncol);
  out.xs = zeros(nrow,ncol);
  out.dL = zeros(nrow,ncol);
  out.fL = zeros(nrow,ncol);
  out.fca = zeros(nrow,ncol);
  out.dT = zeros(nrow,ncol);
  out.fT = zeros(nrow,ncol);
  out.g = zeros(nrow,ncol);
  out.IKr = zeros(nrow,ncol);
  out.IK1 = zeros(nrow,ncol);
  out.INa = zeros(nrow,ncol);
  out.IbNa = zeros(nrow,ncol);
  out.ICaL = zeros(nrow,ncol);
  out.ICaT = zeros(nrow,ncol);
  out.IKs = zeros(nrow,ncol);
  out.INaCa = zeros(nrow,ncol);
  out.INaK = zeros(nrow,ncol);
  out.IpCa = zeros(nrow,ncol);
  out.IbCa = zeros(nrow,ncol);
  out.Irel = zeros(nrow,ncol);
  out.Iup = zeros(nrow,ncol);
  out.Ileak = zeros(nrow,ncol);
return

%-------------------------------------------

function [V,cur] = currents(nnd,V,p,t,dt,Istim)

% This function computes currents and concentrations
% for the ten Tusscher Model
%
% KHWJ ten Tusscher, D Noble, PJ Noble, AV Panfilov. 
%  Am J Phys 286:H1573-H1589, 2004.
% KHWJ ten Tusscher and AV Panfilov. 
%  Am J Phys 291:H1088-H1100, 2006

invRTF = 1.0/p.RTF;
EK = p.RTF*log(p.Ko./V.Ki);
ENa = p.RTF*log(p.Nao./V.Nai);
EKs = p.RTF*log((p.Ko+p.pKNa*p.Nao)./(V.Ki+p.pKNa*V.Nai));
ECa = 0.5*p.RTF*log(p.Cao./V.Cai);
atmp = V.V*invRTF;
rec_iNaK = 1./(1.0 + 0.1245*exp(-0.1*atmp) + 0.0353*exp(-atmp));

atmp1 = V.V - EK;
rec_iK1 = 1./(1 + exp((V.V + 87.0762)/(13.5048))) + 0.02;
cur.IK1 = p.GK1*sqrt(p.Ko/4.85)*rec_iK1.*atmp1;                                   % IK1

cur.IKr = p.GKr*sqrt(p.Ko/4.85)*V.xr1.*V.xr2.*atmp1;                              % IKr

atmp1 = V.V - ENa;
cur.INa = p.GNa*V.m.*V.m.*V.m.*V.h.*V.j.*atmp1;                                   % INa
cur.IbNa = p.GbNa*atmp1;                                                          % IbNa

%
% ICaL
%
atmp1 = 2.0*(V.V)*invRTF;
Id1 = abs(atmp1)<=1.0e-5;
Id2 = abs(atmp1)>1.0e-5;
numICaL = zeros(nnd,1);
denICaL = zeros(nnd,1);
ICaL = zeros(nnd,1);
denICaL(Id1) = exp(atmp1(Id1));
denICaL(Id2) = exp(atmp1(Id2))-1.0;
numICaL(Id1) = V.Cai(Id1).*((1+atmp1(Id1)).*exp(atmp1(Id1)))-0.341*p.Cao;
numICaL(Id2) = atmp1(Id2).*(V.Cai(Id2).*exp(atmp1(Id2))-0.341*p.Cao);
ICaL(Id1) = numICaL(Id1)./denICaL(Id1);
ICaL(Id2) = numICaL(Id2)./denICaL(Id2);
cur.ICaL = 2.0*p.F*p.GCaL*V.dL.*V.fL.*V.fca.*ICaL;
%ICaL = 2.0*p.GCaL*V.dL.*V.fL.*V.fca.*(atmp1*p.F).*(V.Cai.*exp(atmp1)-0.341*p.Cao);
%denICaL = exp(atmp1) - 1.0;
%cur.ICaL = ICaL./denICaL;                                                         % ICaL

cur.ICaT = p.GCaT*V.dT.*V.fT.*(V.V - ECa);                                        % ICaT
cur.IKs = p.GKs.*V.xs.*(V.V - EKs);                                               % IKs

atmp1 = exp(p.gam*atmp);
atmp2 = exp((p.gam - 1.0)*atmp);
denINaCa1 = (p.KmNai^3 + p.Nao^3)*(p.KmCa + p.Cao)*(1.0 + p.ksat*atmp2);
cur.INaCa = p.kNaCa*(atmp1.*(V.Nai.^3)*p.Cao ...
    - p.Nao^3*atmp2.*V.Cai.*p.alf)./denINaCa1;                                    % INaCa

denINaK = (p.Ko + p.KmK)*(V.Nai + p.KmNa);
cur.INaK = p.PNaK*p.Ko*V.Nai.*rec_iNaK./denINaK;                                  % INaK

cur.IpCa = p.GpCa*V.Cai./(p.KpCa + V.Cai);                                        % IpCa
cur.IbCa = p.GbCa*(V.V - ECa); % IbCa

% Calculating total current
IK = cur.IKr + cur.IKs + cur.IK1;
INa = cur.INa + cur.IbNa + cur.INaK + cur.INaCa;
ICa = cur.ICaL + cur.IbCa + cur.IpCa + cur.ICaT;
V.Itot = IK + INa + ICa + Istim;

% Updating Concentrations
[V,cur] = concentrations(cur,V,p,dt,Istim);

% Updating Gates
V = gates(nnd,V,p,dt);

return

% -------------------------------------------

function [V,cur] = concentrations(cur,V,p,dt,Istim)

% Function to update Ion concentrations

invVcF  = 1.0/(p.Vc*p.F);
invVcF2 = 0.5*invVcF;

coefIrel = (p.arel*V.CaSR.*V.CaSR./(p.brel*p.brel+V.CaSR.*V.CaSR) + p.crel);                               
cur.Irel = p.gIrel*coefIrel.*V.dL.*V.g;
cur.Iup = p.Vmxu./(1.0 + ((p.Kup*p.Kup)./(V.Cai.*V.Cai)));
cur.Ileak = p.Vleak*(V.CaSR - V.Cai);

% Cai
coef = 1./(1.0 + (p.Bufc*p.Kbufc)./(V.Cai + p.Kbufc).^2);
dCai = coef.*((-(cur.IbCa + cur.IpCa - 2.0*cur.INaCa + cur.ICaL + cur.ICaT)*invVcF2*p.Cap*p.Ac) - ...
     (cur.Iup - cur.Irel - cur.Ileak));
V.Cai = V.Cai + dt*dCai; 
 
% CaSR
coef = 1./(1.0+(p.Bufsr*p.Kbufsr)./(V.CaSR+p.Kbufsr).^2);
dCaSR = coef.*(cur.Iup - cur.Irel - cur.Ileak)*p.Vc/p.Vsr;
V.CaSR = V.CaSR + dt*dCaSR;

totINa = cur.INa + cur.IbNa + 3.0*(cur.INaK + cur.INaCa);
dNai = -totINa*invVcF*p.Cap*p.Ac;
V.Nai = V.Nai + dt*dNai;

totIK = Istim + cur.IK1 + cur.IKr + cur.IKs - 2.0*cur.INaK;
dKi = -totIK*invVcF*p.Cap*p.Ac;
V.Ki = V.Ki + dt*dKi;

return

% -----------------------------------------

function V = gates(nnd,V,p,dt)

% This function updates the gating variables

% Fast Na+ current

AM = 1./(1.0 + exp(-0.2*(80.0 + V.V)));
BM = 1.95./(1.0 + exp((V.V + 45.0)/6.0)) + ...
     0.1./(1.0 + exp(0.005*(V.V - 60.0)));
TAUM = AM.*BM.*0.9395;
MINF = 1./(1.0 + exp((-58.5 - V.V)/8.025));

Id1 = (V.V >= -40.0);
Id2 = (V.V < -40.0);
TAUH = zeros(nnd,1);
AH1 = 0.0;
BH1 = 0.77./(0.13*(1.0 + exp(-(V.V + 10.66)/11.1)));
TAUH(Id1) = 1./(AH1 + BH1(Id1));
AH2 = 0.057*exp(-(V.V + 80.0)/6.8);
BH2 = 2.7*exp(0.079*V.V) + 3.1E5*exp(0.3485*V.V);
TAUH(Id2) = 1./(AH2(Id2) + BH2(Id2));
TAUH = TAUH*3.5;
HINF = 1./(1.0 + exp((V.V + 70.5727)/7.5));

Id3 = (V.V >= -31.0);
Id4 = (V.V < -31.0);
TAUJ = zeros(nnd,1);
AJ1 = 0.0;
BJ1 = 0.6*exp(0.057*(V.V - 9))./(1.0 + exp(-0.1*(V.V - 9 + 32.0)));
TAUJ(Id3) = 1./(AJ1 + BJ1(Id3));
c1 = -2.5428e4*exp(0.2444*(V.V - 9)) - 6.948e-6*exp(-0.04391*(V.V - 9));
AJ2 = c1.*(V.V - 9 + 37.78)./(1.+exp(0.311*(V.V - 9 + 79.23)));   
BJ2 = 0.02424*exp(-0.01052*(V.V - 9))./(1. + exp(-0.1378*((V.V - 9) + 40.14)));
TAUJ(Id4) = 1./(AJ2(Id4) + BJ2(Id4));
TAUJ = TAUJ*0.8;
JINF = HINF;

% Rapid delay rectifier IKr

Xr1INF = 1./(1.0 + exp((8.87 - V.V)/6.56));
axr1 = 690./(1.0 + exp(0.1*(- 42.0 - V.V)));
bxr1 = 6./(1.0 + exp((V.V + 49.0)/11.5)) + 0.09;
TAUXr1 = (axr1.*bxr1).*1.0798;

Xr2INF = 1./(1.0 + exp((V.V + 85.0664)/22.82));
axr2 = 65.*exp(-(V.V + 85.0).*(V.V + 85.0)/700);
bxr2 = 5.0./(1.0 + exp((V.V - 5.0)/15.0)) + 3.0;
TAUXr2 = (axr2 + bxr2).*0.9443;

% Slow delay rectifier IKs

XsINF = 1./(1.0 + exp((4.9182 - V.V)/30.0));
Axs = (670./(1.0 + exp((-35.0 - V.V)/6.0)));
Bxs = (1./(1.0 + exp((V.V - 5.0)/21.0)));
TAUXs = Axs.*Bxs.*1.0;

% L-Type Ca2+ current ICaL

DLINF = 1./(1.0 + exp((-25.0011 - V.V)/5.478));
Ad = 2.8./(1.0 + exp((-20.0 - V.V)/13.0)) + 2.93;
Bd = 1.4./(1.0 + exp(0.2*(V.V + 5.0)));
Cd = 3.5./(1.0 + exp(0.1*(-5.0 - V.V)));
TAUDL = (Ad.*Bd + Cd).*0.756;

FLINF = 1./(1.0 + exp((V.V + 35.8779)/4.0));
Af = (310.5*exp(-(V.V + 38).^2./120));
Bf = (80./(1 + exp((8 - V.V)./10)));
Cf = (120./(1 + exp((35 + V.V)./10))) + 20;   
TAUFL = (Af + Bf + Cf);		

afca = 1./(1 + (V.Cai./0.000325).^8);
bfca = 0.1./(1 + exp((V.Cai-0.0005)./0.0001));
cfca = 0.2./(1 + exp((V.Cai-0.00075)./0.0008));
FCaINF = (afca + bfca + cfca + 0.23)./1.45;
TAUFCa = 2.0;   

% T-Type Ca2+ current ICaT

DTINF = 1.0./(1.0 + exp(-(V.V + 30.0)/8.5));
TAUDT = 1.0./(1.068*exp((V.V + 26.3)/30.0) + 1.068*exp(-(V.V + 26.3)/30.0));
FTINF = 1.0./(1.0+exp((V.V + 71.0)/9.0));
TAUFT = 1000.0./(15.3*exp(-(V.V + 71.7)/83.3) + 15.0*exp((V.V + 71.7)/15.38));

% g gate - Calcium release

Id1 = (V.Cai < 0.00035);
Id2 = (V.Cai >= 0.00035);
gINF = zeros(nnd,1);
gINF(Id1) = 1./(1.0 + (V.Cai(Id1)/0.00035).^6);
gINF(Id2) = 1./(1.0 + (V.Cai(Id2)/0.00035).^16);

% Update gates

V.m = MINF - (MINF - V.m).*exp(-dt./TAUM);
V.h = HINF - (HINF - V.h).*exp(-dt./TAUH);
V.j = JINF - (JINF - V.j).*exp(-dt./TAUJ);
V.xr1 = Xr1INF - (Xr1INF - V.xr1).*exp(-dt./TAUXr1);
V.xr2 = Xr2INF - (Xr2INF - V.xr2).*exp(-dt./TAUXr2);
V.xs = XsINF - (XsINF - V.xs).*exp(-dt./TAUXs);
V.dL = DLINF - (DLINF - V.dL).*exp(-dt./TAUDL); 
V.fL = FLINF - (FLINF - V.fL).*exp(-dt./TAUFL); 
V.dT = DTINF - (DTINF-V.dT).*exp(-dt./TAUDT);
V.fT = FTINF - (FTINF-V.fT).*exp(-dt./TAUFT);

% g gate

Id1 = ((V.V>-60) & (V.g<=gINF));
gtmp = gINF - (gINF-V.g).*exp(-dt./p.taug);
gtmp(Id1) = V.g(Id1);
V.g = gtmp;

% fca

Id1 = ((V.V>-60) & (V.fca<=FCaINF));
fcatmp = FCaINF - (FCaINF - V.fca).*exp(-dt./TAUFCa);
fcatmp(Id1) = V.fca(Id1);
V.fca = fcatmp;

return