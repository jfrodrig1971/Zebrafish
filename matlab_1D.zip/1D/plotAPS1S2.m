function plotAPS1S2(BCL,BCLseq,dx)
%
% File .mat with restitution data order as follow:
%
% Col  1: S2
% Col  2: APD90 S1
% Col  3: APD90 S2
% Col  4: APD20 S2
% Col  5: APD50 S2
% Col  6: APD80 S2
% Col  7: RMP S2
% Col  8: APA S2
% Col  9: dVdtmax S2
% Col 10: DI
% Col 11: CaT20
% Col 12: CaT50
% Col 13: CaT80

n = length(BCLseq);

fp1 = figure(1);
axfp1 = axes('Parent',fp1);
grid(axfp1,'on');
hold(axfp1,'on');
fp2 = figure(2);
fp2sp1 = subplot(1,2,1); hold;
fp2sp2 = subplot(1,2,2); hold;
fp3 = figure(3);
fp3sp1 = subplot(1,2,1); hold;
fp3sp2 = subplot(1,2,2); hold;
S1S2 = zeros(n,13);

for i = 1:n
    fname = sprintf('S1S2_%d_%d.mat',BCL,BCLseq(i));
    load(fname,'x','out');
    nId = ceil(length(x)*dx)+1;
    t = out.V(:,1);
    V = out.V(:,nId);
    Ca= out.Cai(:,nId);
    tag = sprintf('%d',BCLseq(i));
    plot(axfp1,out.V(:,1),out.V(:,nId),'LineWidth',2,'DisplayName',tag);

    % Processing results

    % Finding Peaks
    [PKS,LOC]=findpeaks(V);
    tp = t(LOC);
    tp1 = tp(tp<min(BCLseq));
    [PK1 I01] = max(PKS(tp<min(BCLseq)));
    tp2 = tp(tp>min(BCLseq));
    [PK2 I02] = max(PKS(tp>min(BCLseq)));
    if(isempty(PK2))
        fprintf('1) S2: %d. No propagating\n',BCLseq(i));
        S1S2(i,end) = -1;
    elseif(PK2<-30)
        fprintf('2) S2: %d. No propagating\n',BCLseq(i));
        S1S2(i,end) = -1;
    else
        fprintf('Procesing S2: %d\n',BCLseq(i));
    
        % Separating S1 and S2
        S1S2(i,1) = BCLseq(i);
        dVdt = diff(V)./diff(t);
        [PKS LOC]=findpeaks(dVdt);
        tp = t(LOC);
        [PK2 I02] = max(PKS(tp>min(BCLseq)));
        LOC2 = LOC(tp>min(BCLseq));
        tendS1 = t(LOC2(I02))-50;
        IS1 = t<tendS1;
        IS2 = t>=tendS1;
        tS1 = t(IS1); 
        VS1 = V(IS1);
        [APDS1,APAS1,VmaxS1,dVdtmaxS1,t0S1,RMPS1,tpeakS1,flagOut] = APDcalc(tS1,VS1,[20 50 80 90]);
        S1S2(i,2) = APDS1(4);
        plot(fp2sp1,tS1,VS1,'Displayname',tag);
        tS2 = t(IS2);
        VS2 = V(IS2);
        [APD,APA,Vmax,dVdtmax,t0,RMP,tpeak,flagOut] = APDcalc(tS2,VS2,[20 50 80 90]);
        plot(fp2sp2,tS2-t0,VS2,'DisplayName',tag);
        S1S2(i,10) = t0 - (t0S1 + APDS1(4));
        S1S2(i,3:9) = [APD([4 1:3]) RMP APA dVdtmax];
        
        % Processing Cai
        dCadt = diff(Ca)./diff(t);
        [PKS LOC] = findpeaks(dCadt);
        tp = t(LOC);
        [PK2 I02] = max(PKS(tp>min(BCLseq)));
        LOC2 = LOC(tp>min(BCLseq));
        tendS1 = t(LOC2(I02))-50;
        IS1 = t<tendS1;
        IS2 = t>=tendS1;
        tS1 = t(IS1); 
        CaS1 = Ca(IS1);
        CaS1 = (CaS1-min(CaS1))/(max(CaS1)-min(CaS1));
        [CaTDS1,tpeak] = CaTDcalc(tS1,CaS1,[20 50 80]);
        plot(fp3sp1,tS1-tpeak+25,CaS1,'Displayname',tag);
        tS2 = t(IS2);
        CaS2 = Ca(IS2);
        CaS2 = (CaS2-min(CaS2))/(max(CaS2)-min(CaS2));       
        [CaTDS2,tpeak] = CaTDcalc(tS2,CaS2,[20 50 80]);
        plot(fp3sp2,tS2-tpeak+25,CaS2,'DisplayName',tag);
        S1S2(i,11:13) = CaTDS2;       
    end
end

S1S2 = S1S2(S1S2(:,end)>=0,:);
xlabel(axfp1,'time (ms)');
ylabel(axfp1,'V_m (m)');
legend(axfp1,'location','best');
hold(axfp1,'off');  

xlabel(fp2sp1,'time (ms)');
ylabel(fp2sp1,'V_m (m)');
title(fp2sp1,'S1');
legend(fp2sp1,'location','best');
grid(fp2sp1,'on');

xlabel(fp2sp2,'time (ms)');
ylabel(fp2sp2,'V_m (m)');
title(fp2sp2,'S2');
legend(fp2sp2,'location','best');
grid(fp2sp2,'on');

xlabel(fp3sp1,'time (ms)');
ylabel(fp3sp1,'Ca_i (-)');
title(fp3sp1,'S1');
legend(fp3sp1,'location','best');
grid(fp3sp1,'on');

xlabel(fp3sp2,'time (ms)');
ylabel(fp3sp2,'Ca_i (-)');
title(fp3sp2,'S2');
legend(fp3sp2,'location','best');
grid(fp3sp2,'on');

fname = sprintf('S1S2rest_%d.mat',BCL);
save(fname,'S1S2');

end