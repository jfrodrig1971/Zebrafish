function plotSS(BCL,control,Fsize)

% Plots SS resutls

sname = sprintf('SS_%d.mat',BCL);  
load(sname);
nnd = length(x);
nId = fix(nnd/2)+1;
t1 = out.V(:,1); 
I1 = t1>=BCL;
V1 = out.V(I1,nId);
Na1 = out.INa(I1,nId);
CaT1 = out.ICaT(I1,nId);
CaL1 = out.ICaL(I1,nId);
Ks1 = out.IKs(I1,nId);
Kr1 = out.IKr(I1,nId);
K11 = out.IK1(I1,nId);
t1 = t1(I1)-BCL;
[APD,APA,Vmax,dVdtmax,t0,RMP,tpeak,flag] = APDcalc(t1,V1,[20 50 80 90]);
AP_features = [RMP;APA;APD(1);APD(2);APD(3);APD(4);dVdtmax;Vmax;tpeak; APD(4)-APD(2)];
sname1 = sprintf('SS_AP_%d.mat',BCL);
save(sname1,'AP_features');
sname2 = sprintf('AP_features_%d.mat',BCL);
save(sname2,'AP_features');

Ca_norm = out.Cai(I1,nId);
minCa = min(Ca_norm);
maxCa = max(Ca_norm);
Ca_norm = Ca_norm/(maxCa);
[dmax,I0] = max(diff(Ca_norm)./diff(t1));
[CaTD,tpeak_Ca] = CaTDcalc(t1-t1(I0),Ca_norm,[20 50 80]);
CaT_features = [CaTD(1);CaTD(2);CaTD(3);tpeak_Ca;];
sname2 = sprintf('CaT_features_%d.mat',BCL);
save(sname2,'CaT_features');

% Plot AP
fp1 = figure(1);
axfp1 = axes('Parent',fp1);
hold(axfp1,'on');
plot(t1,V1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(axfp1,'time (ms)');
ylabel(axfp1,'Vm (mV)');
xlim(axfp1,[-10 300]);
grid(axfp1,'on');
title('Action Potential');

% Plot CaT
Ca_norm = out.Cai(I1,nId);
minCa = min(Ca_norm);
maxCa = max(Ca_norm);
Ca_norm = (Ca_norm - minCa)/(maxCa - minCa);
fp2 = figure(2);
axfp2 = axes('Parent',fp2);
hold(axfp2,'on');
plot(t1,Ca_norm,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(axfp2,'time (ms)');
ylabel(axfp2,'[Ca]_i (mM)');
xlim(axfp2,[0 500]);
grid(axfp2,'on');

% Plot single currents
figure(3);
plot((t1-t1(I0))+7,Na1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{Na} (pA/pF)');
xlim([-10 300]);
grid on;

figure(4);
plot(t1-t1(I0)+7,CaT1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{CaT} (pA/pF)');
xlim([-10 300]);
grid on;

figure(5);
plot(t1-t1(I0)+7,CaL1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{CaL} (pA/pF)');
xlim([-10 300]);
grid on;

figure(6);
plot(t1-t1(I0)+7,Ks1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{Ks} (pA/pF)');
xlim([-10 300]);
grid on;

figure(7);
plot(t1-t1(I0)+7,Kr1,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{Kr} (pA/pF)');
xlim([-10 300]);
grid on;

figure(8);
plot(t1-t1(I0)+7,K11,'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Numerical');
xlabel('time (ms)');
ylabel('I_{K1} (pA/pF)');
xlim([-10 300]);
grid on;

fprintf('AP features     Model\n');
fprintf('RMP     (mV) = %7.3f\n',RMP);
fprintf('APA     (mV) = %7.3f\n',APA);
fprintf('APD20   (ms) = %7.3f\n',APD(1));
fprintf('APD50   (ms) = %7.3f\n',APD(2));
fprintf('APD80   (ms) = %7.3f\n',APD(3));
fprintf('APD90   (ms) = %7.3f\n',APD(4));
fprintf('dVdt (mV/ms) = %7.3f\n',dVdtmax);
fprintf('Vmax    (mV) = %7.3f\n',Vmax);
fprintf('triang  (ms) = %7.3f\n',APD(4)-APD(2));
fprintf('Ca features       Model\n');
fprintf('CaTD20   (ms)   = %7.3f\n',CaTD(1));
fprintf('CaTD50   (ms)   = %7.3f\n',CaTD(2));
fprintf('CaTD80   (ms)   = %7.3f\n',CaTD(3));


legend(axfp1,'location','best');
legend(axfp2,'location','best');
end