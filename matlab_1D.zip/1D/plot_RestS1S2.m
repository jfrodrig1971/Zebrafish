function plot_RestS1S2(BCL0,control,Fsize)

% File .mat with restitution data order as follow:
%
% Col  1: S2
% Col  2: APD90 S1
% Col  3: APD90 S2
% Col  4: APD20 S2
% Col  5: APD50 S2
% Col  6: APD80 S2
% Col  7: RMP S2
% Col  8: APA S2
% Col  9: dVdtmax S2
% Col 10: DI
% Col 11: CaT20
% Col 12: CaT50
% Col 13: CaT80
%
% control: 0 does not plot control curve
%          1 plot control curve

fname = sprintf('S1S2rest_%d.mat',BCL0);
load(fname,'S1S2');
fp4 = figure(4);
sgtitle('S1S2 Restitution Curve');
fp4sp1 = subplot(2,3,1); hold
fp4sp2 = subplot(2,3,2); hold
fp4sp3 = subplot(2,3,3); hold
fp4sp4 = subplot(2,3,4); hold
fp4sp5 = subplot(2,3,5); hold
fp4sp6 = subplot(2,3,6); hold

% APD90
minDI = 80;
DImod = S1S2(:,10);
plot(fp4sp1,DImod(DImod>=minDI),S1S2(DImod>=minDI,3),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp1,'DI (ms)');
ylabel(fp4sp1,'APD_{90} (ms)');
xlim(fp4sp1,[50 300]);
ylim(fp4sp1,[100 200]);
grid(fp4sp1,'on');

% APD80
minDI = 80;
plot(fp4sp2,DImod(DImod>=minDI),S1S2(DImod>=minDI,6),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp2,'DI (ms)');
ylabel(fp4sp2,'APD_{80} (ms)');
xlim(fp4sp2,[50 300]);
ylim(fp4sp2,[100 200]);
grid(fp4sp2,'on');

% APD50
minDI = 80;
plot(fp4sp3,DImod(DImod>=minDI),S1S2(DImod>=minDI,5),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp3,'DI (ms)');
ylabel(fp4sp3,'APD_{50} (ms)');
xlim(fp4sp3,[50 300]);
ylim(fp4sp3,[80 180]);
grid(fp4sp3,'on');

% RMP
minDI = 80;
plot(fp4sp4,DImod(DImod>=minDI),S1S2(DImod>=minDI,7),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp4,'DI (ms)');
ylabel(fp4sp4,'RMP (mV)');
ylim(fp4sp4,[-90 -70]);
xlim(fp4sp4,[50 300]);
ylim(fp4sp4,[-85 -70]);
grid(fp4sp4,'on');

% APA
minDI = 80;
plot(fp4sp5,DImod(DImod>=minDI),S1S2(DImod>=minDI,8),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp5,'DI (ms)');
ylabel(fp4sp5,'APA (mV)');
xlim(fp4sp5,[50 300]);
ylim(fp4sp5,[80 120]);
grid(fp4sp5,'on');

% dVdtmax
minDI = 80;
plot(fp4sp6,DImod(DImod>=minDI),S1S2(DImod>=minDI,9),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp4sp6,'DI (ms)');
ylabel(fp4sp6,'upstrooke (V/s)');
xlim(fp4sp6,[50 300]);
ylim(fp4sp6,[0 50]);
grid(fp4sp6,'on');

% Calcium

fp6 = figure(6);
sgtitle('Calcium S1S2 Restitution Curve');
fp6sp1 = subplot(2,3,1); hold;
fp6sp2 = subplot(2,3,2); hold;
fp6sp3 = subplot(2,3,3); hold;

% CaTD80
plot(fp6sp1,S1S2(1:end-1,1),S1S2(1:end-1,13),'Color',[0.49,0.18,0.56],'LineWidth',2,'DisplayName','Model 1D');
xlabel(fp6sp1,'BCL (ms)');
ylabel(fp6sp1,'CaTD_{80} (ms)');
xlim(fp6sp1,[200 500]);
ylim(fp6sp1,[100 400]);
grid(fp6sp1,'on');

% CaTD50
plot(fp6sp2,S1S2(1:end-1,1),S1S2(1:end-1,12),'Color',[0.49,0.18,0.56],'LineWidth',2);
xlabel(fp6sp2,'BCL (ms)');
ylabel(fp6sp2,'CaTD_{50} (ms)');
xlim(fp6sp2,[200 500]);
ylim(fp6sp2,[50 300]);
grid(fp6sp2,'on');

% CaTD20
plot(fp6sp3,S1S2(1:end-1,1),S1S2(1:end-1,11),'Color',[0.49,0.18,0.56],'LineWidth',2);
xlabel(fp6sp3,'BCL (ms)');
ylabel(fp6sp3,'CaTD_{20} (ms)');
xlim(fp6sp3,[200 500]);
ylim(fp6sp3,[50 250]);
grid(fp6sp3,'on');

legend(fp4sp1,'location','best');
legend(fp6sp1,'location','best');

end